<?php
    include("heda.php");

    // Check if the View Details button is clicked for power supplies
    if(isset($_POST['viewDetails'])) {
        $model = $_POST['model'];

        // Fetch details based on the model for power supplies
        $sql = "SELECT * FROM powersupplies WHERE Model = '$model'";
        $result = mysqli_query($conn, $sql);
        $details = mysqli_fetch_assoc($result);

        // Display the details for power supplies
        $columnNames = "";
        echo "<p>Model name: $columnNames</p>";
        echo "<h2 id='productName'>".$details['Model']."</h2>";
        $columnNames = "";
        echo "<p>Total Watt: $columnNames</p>";
        echo "<p id='productDescription'>".$details['TotalWatt']."</p>";
        $columnNames = "";
        echo "<p>Certification: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Certification']."</p>";
        $columnNames = "";
        echo "<p>Efficiency: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Efficiency']."</p>";
        $columnNames = "";
        echo "<p>Price: $columnNames </p>";
        echo "<p id='productDescription'>".$details['price']."</p>";
        $columnNames = "";
        echo "<p>Waranty: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Warranty']."</p>";
    } else {
        // If View Details button is not clicked, display the power supply list
        $sql = "SELECT * FROM powersupplies";
        $result = mysqli_query($conn, $sql);
        $powersupplies = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Tech Shop</title>
</head>

<body>
    <section id="productDetails">
        <h2 id="productName"></h2>
        <p id="productDescription"></p>
        <p id="productPrice"></p>
        <div class="Container border mb-3">
            <table class="table">
                <?php foreach ($powersupplies as $items): ?>
                    <tr>
                        <td>
                            <?php
                            echo "<h6>" . $items['Model'] . "</h6>" . "Price: " . "<b>" . $items['price'] . "</b> BDT ";
                            ?>
                        </td>
                        <td>
                            <form method="POST" action="cart.php">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <input type="hidden" name="price" value="<?= $items['price'] ?>">
                                <input type="submit" class="btn btn-primary" value="ADD TO CART">
                            </form>
                        </td>
                        <td>
                            <!-- Add a View Details button with a form to submit the model for power supplies -->
                            <form method="POST" action="">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <button type="submit" class="btn btn-info" name="viewDetails">View Details</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </section>

    <footer>
        <p>&copy; 2023 Tech Shop. All rights reserved.</p>
    </footer>

    <!-- Adding Javascript -->
    <!-- <script src="main.js"></script> -->
</body>

</html>
<?php
    }
?>
