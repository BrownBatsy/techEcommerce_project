<?php
    include("heda.php");

    // Check if the View Details button is clicked for Laptops
    if(isset($_POST['viewDetails'])) {
        $model = $_POST['model'];

        // Fetch details based on the model for Laptops
        $sql = "SELECT * FROM laptops WHERE Model = '$model'";
        $result = mysqli_query($conn, $sql);
        $details = mysqli_fetch_assoc($result);

        // Display the details for Laptops
        $columnNames = "";
        echo "<p>Brand And Model: $columnNames</p>";
        echo "<h2 id='productName'>".$details['Model']."</h2>";
        $columnNames = "";
        echo "<p>Processor: $columnNames</h2>";
        echo "<p id='productDescription'>".$details['Processor']."</p>";
        $columnNames = "";
        echo "<p>Total storage : $columnNames</p>";
        echo "<p id='productDescription'>".$details['Storage']."</p>";
        $columnNames = "";
        echo "<p>Ram: $columnNames</p>";
        echo "<p id='productDescription'>".$details['RAM']."</p>";
        $columnNames = "";
        echo "<p>Dimension: $columnNames </p>";
        echo "<p id='productDescription'>".$details['Dimension']."</p>";
        $columnNames = "";
        echo "<p>Display Size and Quality: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Display']."</p>";
        $columnNames = "";
        echo "<p>Battery type: $columnNames </p>";
        echo "<p id='productDescription'>".$details['Battery']."</p>";
        $columnNames = "";
        echo "<p>Laptop Type : $columnNames</p>";
        echo "<p id='productDescription'>".$details['LaptopType']."</p>";
        $columnNames = "";
        echo "<p>Price: $columnNames </p>";
        echo "<p id='productDescription'>".$details['price']." BDT</p>";
        $columnNames = "";
        echo "<p>Warranty: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Warranty']." years</p>";
    } else {
        // If View Details button is not clicked, display the Laptops list
        $sql = "SELECT * FROM laptops";
        $result = mysqli_query($conn, $sql);
        $laptops = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Tech Shop</title>
</head>

<body>
    <section id="productDetails">
        <h2 id="productName"></h2>
        <p id="productDescription"></p>
        <p id="productPrice"></p>
        <div class="Container border mb-3">
            <table class="table">
                <?php foreach ($laptops as $items): ?>
                    <tr>
                        <td>
                            <?php
                                echo "<h6>" . $items['Model'] . "</h6>" . "Price: " . "<b>" . $items['price'] . "</b> BDT ";
                            ?>
                        </td>
                        <td>
                            <form method="POST" action="cart.php">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <input type="hidden" name="price" value="<?= $items['price'] ?>">
                                <input type="submit" class="btn btn-primary" value="ADD TO CART">
                            </form>
                        </td>
                        <td>
                            <!-- Add a View Details button with a form to submit the model for Laptops -->
                            <form method="POST" action="">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <button type="submit" class="btn btn-info" name="viewDetails">View Details</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </section>

    <footer>
        <p>&copy; 2023 Tech Shop. All rights reserved.</p>
    </footer>

    <!-- Adding Javascript -->
    <!-- <script src="main.js"></script> -->
</body>
</html>
<?php
    }
?>
