document.getElementById("drp1").addEventListener("click", function () {
    myFunction(1);
  });
  
  document.getElementById("drp2").addEventListener("click", function () {
    myFunction(2);
  });
  
  function myFunction(val) {
    if (val == 1) {
        var dropdown = document.getElementById("myDropdown");
    } else if (val == 2) {
        var dropdown = document.getElementById("rDropdown");
    } else {
        console.log("Invalid value");
        return;
    }
  
    if (dropdown.classList.contains("show")) {
        dropdown.classList.remove("show");
        dropdown.classList.add("hide");
    } else {
        dropdown.classList.remove("hide");
        dropdown.classList.add("show");
    }
  }
  