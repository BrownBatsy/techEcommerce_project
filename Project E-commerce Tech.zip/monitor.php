<?php
    include("heda.php");

    // Check if the View Details button is clicked
    if(isset($_POST['viewDetails'])) {
        $model = $_POST['model'];

        // Fetch details based on the model
        $sql = "SELECT * FROM monitors WHERE Model = '$model'";
        $result = mysqli_query($conn, $sql);
        $details = mysqli_fetch_assoc($result);

        // Display the details
        $columnNames = "";
        echo "<p>Model name: $columnNames</p>";
        echo "<h2 id='productName'>".$details['Model']."</h2>";
        $columnNames = "";
        echo "<p>Dimension: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Dimension']."</p>";
        $columnNames = "";
        echo "<p>Audio Feature: $columnNames</p>";
        echo "<p id='productDescription'>".$details['AudioFeature']."</p>";
        $columnNames = "";
        echo "<p>Display Resolution: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Resolution']."</p>";
        $columnNames = "";
        echo "<p>Display Type: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Display']."</p>";
        $columnNames = "";
        echo "<p>Refresh Rate: $columnNames</p>";
        echo "<p id='productDescription'>".$details['RefreshRate']."</p>";
        $columnNames = "";
        echo "<p>Aspect Ratio: $columnNames</p>";
        echo "<p id='productDescription'>".$details['AspectRatio']."</p>";
        $columnNames = "";
        echo "<p>Price: $columnNames</p>";
        echo "<p id='productPrice'>".$details['price']." BDT</p>";
        $columnNames = "";
        echo "<p>Warranty: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Warranty']."</p>";
    } else {
        // If View Details button is not clicked, display the product list
        $sql = "SELECT * FROM monitors";
        $result = mysqli_query($conn, $sql);
        $monitors = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Tech Shop</title>
</head>
<body>
    <section id="productDetails">
        <h2 id="productName"></h2>
        <p id="productDescription"></p>
        <p id="productPrice"></p>
        <div class="Container border mb-3">
            <table class="table">
                <?php foreach ($monitors as $items): ?>
                    <tr>
                        <td>
                            <?php echo "<h6>".$items['Model'] ."</h6>". "Price: ". "<b>". $items['price'] . "</b> BDT ";?>
                        </td>
                        <td>
                            <form method="POST" action="cart.php">
                                <input type="hidden" name="model" value="<?=$items['Model']?>">
                                <input type="hidden" name="price" value="<?=$items['price']?>">
                                <input type="submit" class="btn btn-primary" value="ADD TO CART">
                            </form>
                        </td>
                        <td>
                            <form method="POST" action="">
                                <input type="hidden" name="model" value="<?=$items['Model']?>">
                                <input type="submit" class="btn btn-info" name="viewDetails" value="View Details">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </section>

    <footer>
        <p>&copy; 2023 Tech Shop. All rights reserved.</p>
    </footer>

    <!-- Adding Javascript -->
    <!-- <script src="main.js"></script> -->
</body>
</html>
<?php
    }
?>
