<?php
    include("heda.php");

    // Check if the View Details button is clicked for GPUs
    if(isset($_POST['viewDetails'])) {
        $model = $_POST['model'];

        // Fetch details based on the model for GPUs
        $sql = "SELECT * FROM gpus WHERE Model = '$model'";
        $result = mysqli_query($conn, $sql);
        $details = mysqli_fetch_assoc($result);

        // Display the details for GPUs
        echo "<h2 id='productName'>".$details['Model']."</h2>";
        echo "<p id='productDescription'>".$details['Description']."</p>";
        echo "<p id='productPrice'>".$details['Price']." BDT</p>";
    } else {
        // If View Details button is not clicked, display the GPU list
        $sql = "SELECT * FROM gpus";
        $result = mysqli_query($conn, $sql);
        $gpus = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Tech Shop</title>
</head>

<body>
    <section id="productDetails">
        <h2 id="productName"></h2>
        <p id="productDescription"></p>
        <p id="productPrice"></p>
        <div class="Container border mb-3">
            <table class="table">
                <?php foreach ($gpus as $items): ?>
                    <tr>
                        <td>
                            <?php
                                echo "<h6>" . $items['Model'] . "</h6>" . "Price: " . "<b>" . $items['Price'] . "</b> BDT ";
                            ?>
                        </td>
                        <td>
                            <form method="POST" action="cart.php">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <input type="hidden" name="price" value="<?= $items['Price'] ?>">
                                <input type="submit" class="btn btn-primary" value="ADD TO CART">
                            </form>
                        </td>
                        <td>
                            <!-- Add a View Details button with a form to submit the model for GPUs -->
                            <form method="POST" action="">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <button type="submit" class="btn btn-info" name="viewDetails">View Details</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </section>

    <footer>
        <p>&copy; 2023 Tech Shop. All rights reserved.</p>
    </footer>

    <!-- Adding Javascript -->
    <!-- <script src="main.js"></script> -->
</body>
</html>
<?php
    }
?>
