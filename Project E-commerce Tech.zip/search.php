<?php
include("heda.php");

if (isset($_POST['search'])) {
    $searchKey = $_POST["searchKey"];
    $categories = $_POST["categories"];
    $_SESSION['categories'] = $categories;

    $sql = "SELECT * FROM $categories WHERE Model LIKE '%$searchKey%';";
    // echo $sql;

    $result = mysqli_query($conn, $sql);
    // $details = mysqli_fetch_all($result, MYSQLI_ASSOC);

    if (mysqli_num_rows($result) > 0) {
        $details = mysqli_fetch_all($result, MYSQLI_ASSOC);
    }  
    else {
        echo "NO MATCHING PRODUCT";
        $details = array();
    };
}

else if(isset($_POST['viewDetails'])) {
    
    $categories = $_SESSION["categories"];
    $model = $_POST['model'];

    // Fetch details based on the model for Laptops
    $sql = "SELECT * FROM $categories WHERE Model = '$model'";
    $result = mysqli_query($conn, $sql);
    $details = mysqli_fetch_assoc($result);

    // Display the details for Laptops
    
    echo "Brand And Model: <h2 id='productName'>".$details['Model']."</h2>";
    
    echo "<p>Processor: </h2>";
    echo "<p id='productDescription'>".$details['Processor']."</p>";
    
    echo "<p>Total storage : </p>";
    echo "<p id='productDescription'>".$details['Storage']."</p>";
    
    echo "<p>Ram: </p>";
    echo "<p id='productDescription'>".$details['RAM']."</p>";
    
    echo "<p>Dimension: </p>";
    echo "<p id='productDescription'>".$details['Dimension']."</p>";
    
    echo "<p>Display Size and Quality: </p>";
    echo "<p id='productDescription'>".$details['Display']."</p>";
    
    echo "<p>Battery type: </p>";
    echo "<p id='productDescription'>".$details['Battery']."</p>";
    
    echo "<p>Laptop Type : </p>";
    echo "<p id='productDescription'>".$details['LaptopType']."</p>";
    
    echo "<p>Price: </p>";
    echo "<p id='productDescription'>".$details['price']." BDT</p>";
    
    echo "<p>Warranty: </p>";
    echo "<p id='productDescription'>".$details['Warranty']." years</p>";
} 

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Tech Shop</title>
</head>

<body>
    <section id="productDetails">
        <h2 id="productName"></h2>
        <p id="productDescription"></p>
        <p id="productPrice"></p>
        <div class="Container border mb-3">
            <table class="table">
                <?php  if (count($details)>0) {
                    foreach ($details as $items): ?>
                        <tr>
                            <td>
                                <?php
                                echo "<h6>" . $items['Model'] . "</h6>" . "Price: " . "<b>" . $items['price'] . "</b> BDT ";
                                ?>
                            </td>
                            <td>
                                <form method="POST" action="cart.php">
                                    <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                    <input type="hidden" name="price" value="<?= $items['price'] ?>">
                                    <input type="submit" class="btn btn-primary" value="ADD TO CART">
                                </form>
                            </td>
                            <td>
                                <!-- Add a View Details button with a form to submit the model for Monitors -->
                                <form method="POST" action="">
                                    <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                    <button type="submit" class="btn btn-info" name="viewDetails">View Details</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; }?>            
            </table>
        </div>
    </section>

    <footer>
        <p>&copy; 2023 Tech Shop. All rights reserved.</p>
    </footer>

    <!-- Adding Javascript -->
    <!-- <script src="main.js"></script> -->
</body>

</html>