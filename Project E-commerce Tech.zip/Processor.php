<?php
    include("heda.php");

    // Check if the View Details button is clicked for RAM
    if(isset($_POST['viewDetails'])) {
        $model = $_POST['model'];

        // Fetch details based on the model for RAM
        $sql = "SELECT * FROM processors WHERE Model = '$model'";
        $result = mysqli_query($conn, $sql);
        $details = mysqli_fetch_assoc($result);

        // Display the details for RAM
        $columnNames = "";
        echo "<p>Brand: $columnNames</p>";
        echo "<h2 id='productName'>".$details['Brand']."</h2>";
        $columnNames = "";
        echo "<p>Model Name : $columnNames</p>";
        echo "<p id='productDescription'>".$details['Model']."</h1>";
        $columnNames = "";
        echo "<p>Threads: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Threads']."</p>";
        $columnNames = "";
        echo "<p>Cores: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Cores']."</p>";
        $columnNames = "";
        echo "<p>Cache size: $columnNames </p>";
        echo "<p id='productDescription'>".$details['CacheSize']."</p>";
        $columnNames = "";
        echo "<p>Clock Speed: $columnNames</p>";
        echo "<p id='productDescription'>".$details['ClockSpeed']."</p>";
        $columnNames = "";
        echo "<p>Price: $columnNames </p>";
        echo "<p id='productDescription'>".$details['price']."</p>";
        $columnNames = "";
        echo "<p>Waranty: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Warranty']."</p>";
    } else {
        // If View Details button is not clicked, display the RAM list
        $sql = "SELECT * FROM processors";
        $result = mysqli_query($conn, $sql);
        $ram = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Tech Shop</title>
</head>

<body>
    <section id="productDetails">
        <h2 id="productName"></h2>
        <p id="productDescription"></p>
        <p id="productPrice"></p>
        <div class="Container border mb-3">
            <table class="table">
                <?php foreach ($ram as $items): ?>
                    <tr>
                        <td>
                            <?php
                                echo "<h6>" . $items['Model'] . "</h6>" . "price: " . "<b>" . $items['price'] . "</b> BDT ";
                            ?>
                        </td>
                        <td>
                            <form method="POST" action="cart.php">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <input type="hidden" name="price" value="<?= $items['price'] ?>">
                                <input type="submit" class="btn btn-primary" value="ADD TO CART">
                            </form>
                        </td>
                        <td>
                            <!-- Add a View Details button with a form to submit the model for RAM -->
                            <form method="POST" action="">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <button type="submit" class="btn btn-info" name="viewDetails">View Details</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </section>

    <footer>
        <p>&copy; 2023 Tech Shop. All rights reserved.</p>
    </footer>

    <!-- Adding Javascript -->
    <!-- <script src="main.js"></script> -->
</body>
</html>
<?php
    }
?>
