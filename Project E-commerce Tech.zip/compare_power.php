<?php
$etag = md5_file('compare_power.css');
header("ETag: $etag");

include("heda.php");

// Fetching Courses From Database
$sql = "SELECT * FROM powersupplies";
$result = mysqli_query($conn, $sql);
$rams = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html>

<head>
  <link rel="stylesheet" href="compare_power.css">
</head>

<body>

  <h1>Comparison:</h1>

  <div class="flex-container">
    <!-- First Comparison Dropdown -->
    <div class="compares">
      <p>Select the product you want to compare</p>
      <div id="drp1" class="dropdown">
        <button class="dropbtn">Select Product</button>
        <div id="myDropdown" class="dropdown-content hide">
          <!-- Modify the options based on your requirements -->
          <form id='add' action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
            <select name="selectRams" multiple class="form-control">
              <?php foreach ($rams as $ram): ?>
                <option class="p-2 border mb-2 rounded" value="<?= $ram['Model'];?>">
                  <?= $ram['Model'] ; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </form>
        </div>
      </div>
    </div>

    <!-- Second Comparison Dropdown -->
    <div class="compares">
      <p>Select the product you want to compare</p>
      <div id="drp2" class="dropdown">
        <button class="dropbtn">Select Product</button>
        <div id="rDropdown" class="dropdown-content hide">
          <!-- Modify the options based on your requirements -->
          <form id='add' action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
            <select name="selectRams" multiple class="form-control">
              <?php foreach ($rams as $ram): ?>
                <option class="p-2 border mb-2 rounded" value="<?= $ram['Model'];?>">
                  <?= $ram['Model'] ; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Javascript -->
  <script src="compare_power.js"></script>

</body>

</html>