<?php
    include("heda.php");

    // Check if the View Details button is clicked for Casing Coolers
    if(isset($_POST['viewDetails'])) {
        $model = $_POST['model'];

        // Fetch details based on the model for Casing Coolers
        $sql = "SELECT * FROM casingcoolers WHERE Model = '$model'";
        $result = mysqli_query($conn, $sql);
        $details = mysqli_fetch_assoc($result);

        // Display the details for Casing Coolers
        $columnNames = "";
        echo "<p>Brand Name: $columnNames</p>";
        echo "<h2 id='productName'>".$details['Brand']."</h2>";
        $columnNames = "";
        echo "<p>Model: $columnNames</h2>";
        echo "<p id='productDescription'>".$details['Model']."</p>";
        $columnNames = "";
        echo "<p>Noise Level : $columnNames</p>";
        echo "<p id='productDescription'>".$details['NoiseLevel']."</p>";
        $columnNames = "";
        echo "<p>Air Flow: $columnNames</p>";
        echo "<p id='productDescription'>".$details['AirFlow']." FM </p>";
        $columnNames = "";
        echo "<p>Type of the Cooler: $columnNames </p>";
        echo "<p id='productDescription'>".$details['CoolerType']."</p>";
        $columnNames = "";
        echo "<p>Price: $columnNames </p>";
        echo "<p id='productDescription'>".$details['price']." BDT</p>";
        $columnNames = "";
        echo "<p>Warranty: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Warranty']." years</p>";
    } else {
        // If View Details button is not clicked, display the Casing Coolers list
        $sql = "SELECT * FROM casingcoolers";
        $result = mysqli_query($conn, $sql);
        $casingcoolers = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Tech Shop</title>
</head>

<body>
    <section id="productDetails">
        <h2 id="productName"></h2>
        <p id="productDescription"></p>
        <p id="productPrice"></p>
        <div class="Container border mb-3">
            <table class="table">
                <?php foreach ($casingcoolers as $items): ?>
                    <tr>
                        <td>
                            <?php
                                echo "<h6>" . $items['Model'] . "</h6>" . "Price: " . "<b>" . $items['price'] . "</b> BDT ";
                            ?>
                        </td>
                        <td>
                            <form method="POST" action="cart.php">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <input type="hidden" name="price" value="<?= $items['price'] ?>">
                                <input type="submit" class="btn btn-primary" value="ADD TO CART">
                            </form>
                        </td>
                        <td>
                            <!-- Add a View Details button with a form to submit the model for Casing Coolers -->
                            <form method="POST" action="">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <button type="submit" class="btn btn-info" name="viewDetails">View Details</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </section>

    <footer>
        <p>&copy; 2023 Tech Shop. All rights reserved.</p>
    </footer>

    <!-- Adding Javascript -->
    <!-- <script src="main.js"></script> -->
</body>
</html>
<?php
    }
?>
