<?php
session_start();
$_SESSION['total'] = 0;
$_SESSION["productNameArr"] = array();
$_SESSION["productPriceArr"] = array();
$_SESSION["productQuantityArr"] = array();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Computer Components Store - Cart</title>
    <link rel="stylesheet" href="style.css">
    
    
</head>

<body>
    <div class="cart-container m-5">
        <h2>THANK YOU FOR SHOPPING WITH US</h2>
    </div>
</body>

</html>