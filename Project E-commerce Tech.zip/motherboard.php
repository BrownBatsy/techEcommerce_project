<?php
    include("heda.php");

    // Check if the View Details button is clicked for Monitors
    if(isset($_POST['viewDetails'])) {
        $model = $_POST['model'];

        // Fetch details based on the model for Monitors
        $sql = "SELECT * FROM motherboards WHERE Model = '$model'";
        $result = mysqli_query($conn, $sql);
        $details = mysqli_fetch_assoc($result);

        // Display the details for Monitors
        // Display the details for Laptops
        $columnNames = "";
        echo "<p>Brand And Model: $columnNames</p>";
        echo "<h2 id='productName'>".$details['Model']."</h2>";
        $columnNames = "";
        echo "<p>Socket Type: $columnNames</h2>";
        echo "<p id='productDescription'>".$details['SocketType']."</p>";
        $columnNames = "";
        echo "<p>Form Factor: $columnNames</p>";
        echo "<p id='productDescription'>".$details['FormFactor']."</p>";
        $columnNames = "";
        echo "<p>Toal Ram Slot: $columnNames</p>";
        echo "<p id='productDescription'>".$details['RAMSlots']."</p>";
        $columnNames = "";
        echo "<p>Chipset: $columnNames </p>";
        echo "<p id='productDescription'>".$details['Chipset']."</p>";
        $columnNames = "";
        echo "<p> Total Ports : $columnNames</p>";
        echo "<p id='productDescription'>".$details['Ports']."</p>";
        $columnNames = "";
        echo "<p>Extra Features: $columnNames </p>";
        echo "<p id='productDescription'>".$details['ExtraFeatures']."</p>";
        $columnNames = "";
        echo "<p>Price: $columnNames </p>";
        echo "<p id='productDescription'>".$details['price']." BDT</p>";
        $columnNames = "";
        echo "<p>Warranty: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Warranty']." years</p>";
    } else {
        // If View Details button is not clicked, display the Monitors list
        $sql = "SELECT * FROM motherboards";
        $result = mysqli_query($conn, $sql);
        $monitors = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Tech Shop</title>
</head>

<body>
    <section id="productDetails">
        <h2 id="productName"></h2>
        <p id="productDescription"></p>
        <p id="productPrice"></p>
        <div class="Container border mb-3">
            <table class="table">
                <?php foreach ($monitors as $items): ?>
                    <tr>
                        <td>
                            <?php
                                echo "<h6>" . $items['Model'] . "</h6>" . "Price: " . "<b>" . $items['price'] . "</b> BDT ";
                            ?>
                        </td>
                        <td>
                            <form method="POST" action="cart.php">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <input type="hidden" name="price" value="<?= $items['price'] ?>">
                                <input type="submit" class="btn btn-primary" value="ADD TO CART">
                            </form>
                        </td>
                        <td>
                            <!-- Add a View Details button with a form to submit the model for Monitors -->
                            <form method="POST" action="">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <button type="submit" class="btn btn-info" name="viewDetails">View Details</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </section>

    <footer>
        <p>&copy; 2023 Tech Shop. All rights reserved.</p>
    </footer>

    <!-- Adding Javascript -->
    <!-- <script src="main.js"></script> -->
</body>
</html>
<?php
    }
?>
