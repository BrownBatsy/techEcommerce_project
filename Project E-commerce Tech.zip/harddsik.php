<?php
    include("heda.php");

    // Check if the View Details button is clicked for Storage Devices
    if(isset($_POST['viewDetails'])) {
        $model = $_POST['model'];

        // Fetch details based on the model for Storage Devices
        $sql = "SELECT * FROM storagedevices WHERE Model = '$model'";
        $result = mysqli_query($conn, $sql);
        $details = mysqli_fetch_assoc($result);

        // Display the details for Storage Devices
        // Display the details for Laptops
        $columnNames = "";
        echo "<p> Brand Name: $columnNames</p>";
        echo "<h2  id='productName'>".$details['Brand']."</h2>";
        $columnNames = "";
        echo "<p> Model : $columnNames</p>";
        echo "<h2  id='productName'>".$details['Model']."</h2>";
        $columnNames = "";
        echo "<p> Read time : $columnNames</h2>";
        echo "<p id='productDescription'>".$details['ReadTime']."MBPS</p>";
        $columnNames = "";
        echo "<p> Write time : $columnNames</p>";
        echo "<p id='productDescription'>".$details['WriteTime']."MBPS</p>";
        $columnNames = "";
        echo "<p> Storage: $columnNames</p>";
        echo "<p id='productDescription'>".$details['StorageCapacity']."</p>";
        $columnNames = "";
        echo "<p>Price: $columnNames </p>";
        echo "<p id='productDescription'>".$details['price']." BDT</p>";
        $columnNames = "";
        echo "<p>Warranty: $columnNames</p>";
        echo "<p id='productDescription'>".$details['Warranty']." years</p>";
    } else {
        // If View Details button is not clicked, display the Storage Devices list
        $sql = "SELECT * FROM storagedevices";
        $result = mysqli_query($conn, $sql);
        $storagedevices = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Tech Shop</title>
</head>

<body>
    <section id="productDetails">
        <h2 id="productName"></h2>
        <p id="productDescription"></p>
        <p id="productPrice"></p>
        <div class="Container border mb-3">
            <table class="table">
                <?php foreach ($storagedevices as $items): ?>
                    <tr>
                        <td>
                            <?php
                                echo "<h6>" . $items['Model'] . "</h6>" . "Price: " . "<b>" . $items['price'] . "</b> BDT ";
                            ?>
                        </td>
                        <td>
                            <form method="POST" action="cart.php">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <input type="hidden" name="price" value="<?= $items['price'] ?>">
                                <input type="submit" class="btn btn-primary" value="ADD TO CART">
                            </form>
                        </td>
                        <td>
                            <!-- Add a View Details button with a form to submit the model for Storage Devices -->
                            <form method="POST" action="">
                                <input type="hidden" name="model" value="<?= $items['Model'] ?>">
                                <button type="submit" class="btn btn-info" name="viewDetails">View Details</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </section>

    <footer>
        <p>&copy; 2023 Tech Shop. All rights reserved.</p>
    </footer>

    <!-- Adding Javascript -->
    <!-- <script src="main.js"></script> -->
</body>

</html>
<?php
    }
?>
