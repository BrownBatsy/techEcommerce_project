<?php
    include("heda.php");

    // Assume you have received product names as query parameters
    $product1 = isset($_GET['product1']) ? $_GET['product1'] : '';
    $product2 = isset($_GET['product2']) ? $_GET['product2'] : '';

    function getProductDetails($conn, $productName) {
        $sql = "SELECT * FROM products WHERE name = '$productName'";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            return mysqli_fetch_assoc($result);
        } else {
            echo "Error fetching product details: " . mysqli_error($conn);
            exit();
        }
    }

    $product1Details = getProductDetails($conn, $product1);
    $product2Details = getProductDetails($conn, $product2);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Product Comparison - Tech Shop</title>
    <!-- Add your styles for the comparison page here -->
    <style>
        /* Add your styles for the comparison page here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        nav {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
        }

        .logo img {
            max-width: 100%;
            height: auto;
        }

        .items {
            display: flex;
            justify-content: space-around;
            align-items: center;
            margin-top: 10px;
        }

        .items a {
            color: white;
            text-decoration: none;
            padding: 10px;
            border-radius: 5px;
            background-color: #555;
        }

        #searchInput {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .productComparison {
            display: flex;
            justify-content: space-around;
            padding: 20px;
        }

        .product {
            border: 1px solid #ddd;
            padding: 20px;
            margin: 10px;
            text-align: center;
            width: 45%;
            box-sizing: border-box;
        }

        .product img {
            max-width: 100%;
            height: auto;
        }

        #productDetails {
            padding: 20px;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>

<body>

    <nav>
        <div class="logo">
            <img src="./Shop%20Logo.F.png" alt="logo">
        </div>
        <div class="items">
            <a href="index.php">Home</a>
            <a target="_blank" href="https://matias.ma/nsfw/" id="showProducts">Products</a>
            <input type="text" id="searchInput" placeholder="Search products...">
        </div>
    </nav>

    <section class="productComparison">
        <div class="product">
            <h2><?= $product1Details['name'] ?></h2>
            <img src="<?= $product1Details['image'] ?>" alt="<?= $product1Details['name'] ?>">
            <p><?= $product1Details['description'] ?></p>
            <p>Price: <b><?= $product1Details['price'] ?></b> BDT</p>
        </div>

        <div class="product">
            <h2><?= $product2Details['name'] ?></h2>
            <img src="<?= $product2Details['image'] ?>" alt="<?= $product2Details['name'] ?>">
            <p><?= $product2Details['description'] ?></p>
            <p>Price: <b><?= $product2Details['price'] ?></b> BDT</p>
        </div>
    </section>

    <footer>
        <p>&copy; 2023 Tech Shop. All rights reserved.</p>
    </footer>

    <!-- Adding Javascript -->
    <script src="main.js"></script>
</body>

</html>
